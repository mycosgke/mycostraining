const DiceGame = {
    elements: {
        die1: null,
        die2: null,
        sumDisplay: null,
        button: null
    },

    init: function() {
        this.elements.die1 = document.getElementById('die1');
        this.elements.die2 = document.getElementById('die2');
        this.elements.sumDisplay = document.getElementById('sum');
        this.elements.button = document.querySelector('button');

        // Add hover effect handlers
        this.elements.die1.addEventListener('mouseover', () => this.handleDieHover(this.elements.die1));
        this.elements.die2.addEventListener('mouseover', () => this.handleDieHover(this.elements.die2));

        this.rollDice();
    },

    handleDieHover: function(die) {
        if (!die.classList.contains('rolling')) {
            die.style.transform = 'translateY(-5px)';
        }
    },

    updateDots: function(die, value) {
        die.setAttribute('data-value', value);
        const dots = die.querySelectorAll('.dot');

        // First hide all dots
        dots.forEach(dot => dot.style.display = 'none');

        // Show dots with fade-in effect
        setTimeout(() => {
            for (let i = 0; i < value; i++) {
                const dot = dots[i];
                dot.style.display = 'block';
                dot.style.opacity = '0';
                dot.style.transition = 'opacity 0.3s ease';

                setTimeout(() => {
                    dot.style.opacity = '1';
                }, 50 * i);
            }
        }, 100);
    },

    getRandomDiceValue: function() {
        return Math.floor(Math.random() * 6) + 1;
    },

    rollDice: function() {
        if (this.elements.button.disabled) return;

        this.elements.button.disabled = true;
        this.elements.sumDisplay.style.opacity = '0';

        // Add rolling animation with 3D effect
        this.elements.die1.classList.add('rolling');
        this.elements.die2.classList.add('rolling');

        const value1 = this.getRandomDiceValue();
        const value2 = this.getRandomDiceValue();
        const sum = value1 + value2;

        setTimeout(() => {
            this.elements.die1.classList.remove('rolling');
            this.elements.die2.classList.remove('rolling');

            // Update dots with delay for smooth transition
            setTimeout(() => {
                this.updateDots(this.elements.die1, value1);
                this.updateDots(this.elements.die2, value2);

                // Fade in sum
                this.elements.sumDisplay.textContent = `Sum: ${sum}`;
                this.elements.sumDisplay.style.transition = 'opacity 0.5s ease';
                this.elements.sumDisplay.style.opacity = '1';

                this.elements.button.disabled = false;
            }, 100);
        }, 1000);
    }
};

document.addEventListener('DOMContentLoaded', () => DiceGame.init());